import { AbstractControl, FormGroup } from "@angular/forms";
export function symbolValidator(el: AbstractControl){
    //returns an object if there is any error
if(el.hasError('required')) return null;
    //returns null if everything is okay
    if(el.value.indexOf('@')=== -1){
    return{
        symbol: true
    }
}
    return null;
}
export function passwordMatch(form: FormGroup){
    const password=form.get('password');
    const confirmPassword=form.get('confirmPassword');

    if(password.value=== confirmPassword.value){
        confirmPassword.setErrors(null);
    }
    else{
        confirmPassword.setErrors({
            passwordMatch: true
        })
    }

    return null;
}