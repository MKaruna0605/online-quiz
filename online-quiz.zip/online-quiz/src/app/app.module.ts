import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Routes, RouterModule} from '@angular/router';


import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { LoginComponent } from './components/shared/login/login.component';
import { QuizComponent } from './components/quiz/quiz.component';
import { AptitudeComponent } from './components/quiz/aptitude/aptitude.component';
import { VerbalComponent } from './components/quiz/verbal/verbal.component';
import { CurrentComponent } from './components/quiz/current/current.component';
import { HomeComponent } from './components/home/home.component';
import { LogoutComponent } from './components/quiz/logout/logout.component';
import { GKComponent } from './components/quiz/gk/gk.component';
import { QuizOneComponent } from './components/quiz-one/quiz-one.component';
import { RegisterComponent } from './components/register/register.component';
import { MpageComponent } from './components/shared/mpage/mpage.component';
import { ReviewComponent } from './components/review/review.component';
import { ResultComponent } from './components/result/result.component';

const routes: Routes=[
  {path:'',redirectTo:'/mpage',pathMatch:'full'},
  {path: 'mpage',component:MpageComponent},
  {path: 'login',component: LoginComponent},
  { path: 'register',component:RegisterComponent},
  {path: 'quiz-one',component:QuizOneComponent},
  {path: 'quiz',component:QuizComponent},
  { path: 'aptitude', component:AptitudeComponent},
  { path: 'verbal', component:VerbalComponent},
  { path: 'current', component:CurrentComponent},
  { path: 'gk', component:GKComponent},
  {path: 'home',component:HomeComponent},
  {path: 'review',component: ReviewComponent},
  {path: 'result',component: ResultComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    LoginComponent,
    QuizComponent,
    AptitudeComponent,
    VerbalComponent,
    CurrentComponent,
    LogoutComponent,
    GKComponent,
    HomeComponent,
    QuizOneComponent,
    RegisterComponent,
    MpageComponent,
    ReviewComponent,
    ResultComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
