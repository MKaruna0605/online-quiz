import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-one',
  templateUrl: './quiz-one.component.html',
  styleUrls: ['./quiz-one.component.css']
})
export class QuizOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
