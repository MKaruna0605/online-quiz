import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verbal',
  templateUrl: './verbal.component.html',
  styleUrls: ['./verbal.component.css']
})
export class VerbalComponent implements OnInit {
  model:any=[];
  q1:string="Question 1";
  q2:string="Question 2";
  q3:string="Question 3";
  q4:string="Question 4";
  q5:string="Question 5";
  q6:string="Question 6";
  q7:string="Question 7";
  q8:string="Question 8";
  q9:string="Question 9";
  q10:string="Question 10";
  msg:string="You Inputed";
  cor:string="Correct answer is";
  cor1:string="A";
  cor2:string="A";
  cor3:string="A";
  cor4:string="D";
  cor5:string="D";
  cor6:string="C";
  cor7:string="B";
  cor8:string="C";
  cor9:string="B";
  cor10:string="B";
  v:string="hidden";
  
  constructor() { }

  ngOnInit() {
  }

  show(){
    console.log(this.model.s);
    this.v="visible";
    document.getElementById("dvi").style.visibility = "visible";
  }
}
