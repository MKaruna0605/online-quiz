import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mpage',
  templateUrl: './mpage.component.html',
  styleUrls: ['./mpage.component.css']
})
export class MpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
