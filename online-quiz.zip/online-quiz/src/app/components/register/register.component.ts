import { Component, OnInit } from '@angular/core';

import { FormBuilder,FormGroup,FormControl, Validators } from '@angular/forms';
import { symbolValidator,passwordMatch } from '../../helpers/validation';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register: FormGroup;

  constructor(private builder: FormBuilder) { }

  ngOnInit() {
    /* 
    this.register=new FormFroup({
      name: new FormControl('asssa')
    })*/
this.buildForm();
}
buildForm(){
  this.register=this.builder.group({
    name: ['',Validators.required],
    email:['',Validators.compose([Validators.required,Validators.email])],
    password:['',Validators.compose([Validators.required,symbolValidator])],
    confirmPassword:''
  },{
    validator:passwordMatch //custom global validator
  
  });
  }
}

